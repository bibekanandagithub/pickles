﻿namespace RemoteFileSystemTester
{
    partial class frmRfs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRfs));
            this.tvPaths = new System.Windows.Forms.TreeView();
            this.ilGlobal = new System.Windows.Forms.ImageList(this.components);
            this.lvFiles = new System.Windows.Forms.ListView();
            this.chItemName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chLastModDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chFileSize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbBack = new System.Windows.Forms.ToolStripButton();
            this.currentPath = new System.Windows.Forms.ToolStripTextBox();
            this.btConnect = new System.Windows.Forms.ToolStripButton();
            this.tsMain = new System.Windows.Forms.ToolStrip();
            this.lblStatus = new System.Windows.Forms.ToolStripLabel();
            this.pbFileTransfer = new System.Windows.Forms.ToolStripProgressBar();
            this.btTransferCancel = new System.Windows.Forms.ToolStripButton();
            this.lvRemoteSystemHeader = new System.Windows.Forms.ListView();
            this.colRemoteSystem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            this.tsMain.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tvPaths
            // 
            this.tvPaths.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tvPaths.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tvPaths.FullRowSelect = true;
            this.tvPaths.ImageIndex = 0;
            this.tvPaths.ImageList = this.ilGlobal;
            this.tvPaths.Location = new System.Drawing.Point(0, 125);
            this.tvPaths.Name = "tvPaths";
            this.tvPaths.SelectedImageIndex = 0;
            this.tvPaths.ShowLines = false;
            this.tvPaths.ShowRootLines = false;
            this.tvPaths.Size = new System.Drawing.Size(178, 384);
            this.tvPaths.TabIndex = 0;
            this.tvPaths.BeforeCollapse += new System.Windows.Forms.TreeViewCancelEventHandler(this.tvPaths_BeforeCollapse);
            this.tvPaths.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.tvPaths_BeforeExpand);
            this.tvPaths.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.tvPaths_AfterExpand);
            this.tvPaths.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvPaths_AfterSelect);
            this.tvPaths.DoubleClick += new System.EventHandler(this.tvPaths_DoubleClick);
            this.tvPaths.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tvPaths_MouseDown);
            // 
            // ilGlobal
            // 
            this.ilGlobal.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilGlobal.ImageStream")));
            this.ilGlobal.TransparentColor = System.Drawing.Color.Transparent;
            this.ilGlobal.Images.SetKeyName(0, "drive-harddisk-8.png");
            this.ilGlobal.Images.SetKeyName(1, "text-x-generic-template.png");
            this.ilGlobal.Images.SetKeyName(2, "folder-open-5.png");
            this.ilGlobal.Images.SetKeyName(3, "computer-4.png");
            // 
            // lvFiles
            // 
            this.lvFiles.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lvFiles.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvFiles.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chItemName,
            this.chLastModDate,
            this.chType,
            this.chFileSize});
            this.lvFiles.LargeImageList = this.ilGlobal;
            this.lvFiles.Location = new System.Drawing.Point(178, 101);
            this.lvFiles.Name = "lvFiles";
            this.lvFiles.Size = new System.Drawing.Size(446, 407);
            this.lvFiles.SmallImageList = this.ilGlobal;
            this.lvFiles.TabIndex = 1;
            this.lvFiles.UseCompatibleStateImageBehavior = false;
            this.lvFiles.View = System.Windows.Forms.View.Details;
            this.lvFiles.DoubleClick += new System.EventHandler(this.lvFiles_DoubleClick);
            this.lvFiles.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lvFiles_MouseDown);
            this.lvFiles.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lvFiles_MouseMove);
            this.lvFiles.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lvFiles_MouseUp);
            // 
            // chItemName
            // 
            this.chItemName.Text = "Name";
            this.chItemName.Width = 175;
            // 
            // chLastModDate
            // 
            this.chLastModDate.Text = "Last Modified";
            this.chLastModDate.Width = 75;
            // 
            // chType
            // 
            this.chType.Text = "Type";
            // 
            // chFileSize
            // 
            this.chFileSize.Text = "Size";
            this.chFileSize.Width = 75;
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbBack,
            this.currentPath,
            this.btConnect});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(624, 25);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbBack
            // 
            this.tsbBack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbBack.Image = ((System.Drawing.Image)(resources.GetObject("tsbBack.Image")));
            this.tsbBack.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBack.Name = "tsbBack";
            this.tsbBack.Size = new System.Drawing.Size(23, 22);
            this.tsbBack.Text = "Back";
            this.tsbBack.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // currentPath
            // 
            this.currentPath.AutoSize = false;
            this.currentPath.Name = "currentPath";
            this.currentPath.Size = new System.Drawing.Size(550, 18);
            // 
            // btConnect
            // 
            this.btConnect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btConnect.Image = ((System.Drawing.Image)(resources.GetObject("btConnect.Image")));
            this.btConnect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btConnect.Name = "btConnect";
            this.btConnect.Size = new System.Drawing.Size(23, 22);
            this.btConnect.Text = "Connect to the server.";
            this.btConnect.Click += new System.EventHandler(this.btConnect_Click);
            // 
            // tsMain
            // 
            this.tsMain.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tsMain.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblStatus,
            this.pbFileTransfer,
            this.btTransferCancel});
            this.tsMain.Location = new System.Drawing.Point(0, 511);
            this.tsMain.Name = "tsMain";
            this.tsMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.tsMain.Size = new System.Drawing.Size(624, 25);
            this.tsMain.TabIndex = 4;
            this.tsMain.Text = "toolStrip2";
            // 
            // lblStatus
            // 
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(29, 22);
            this.lblStatus.Text = "Idle.";
            // 
            // pbFileTransfer
            // 
            this.pbFileTransfer.Name = "pbFileTransfer";
            this.pbFileTransfer.Size = new System.Drawing.Size(100, 22);
            this.pbFileTransfer.Visible = false;
            // 
            // btTransferCancel
            // 
            this.btTransferCancel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btTransferCancel.Image = ((System.Drawing.Image)(resources.GetObject("btTransferCancel.Image")));
            this.btTransferCancel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btTransferCancel.Name = "btTransferCancel";
            this.btTransferCancel.Size = new System.Drawing.Size(23, 22);
            this.btTransferCancel.Text = "Cancel";
            this.btTransferCancel.Visible = false;
            this.btTransferCancel.Click += new System.EventHandler(this.toolStripButton1_Click_1);
            // 
            // lvRemoteSystemHeader
            // 
            this.lvRemoteSystemHeader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lvRemoteSystemHeader.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvRemoteSystemHeader.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colRemoteSystem});
            this.lvRemoteSystemHeader.Location = new System.Drawing.Point(0, 101);
            this.lvRemoteSystemHeader.Name = "lvRemoteSystemHeader";
            this.lvRemoteSystemHeader.Size = new System.Drawing.Size(187, 38);
            this.lvRemoteSystemHeader.TabIndex = 5;
            this.lvRemoteSystemHeader.UseCompatibleStateImageBehavior = false;
            this.lvRemoteSystemHeader.View = System.Windows.Forms.View.Details;
            // 
            // colRemoteSystem
            // 
            this.colRemoteSystem.Text = "Remote System";
            this.colRemoteSystem.Width = 177;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.GhostWhite;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lblInstructions);
            this.panel1.Location = new System.Drawing.Point(0, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(624, 70);
            this.panel1.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(136, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "2.) Double click folders to open them";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(136, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(411, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "1.) Click the connect button in the top right corner to connect to your remote ma" +
    "chine.";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::RemoteFileSystemTester.Properties.Resources.edit_copy_2;
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(75, 67);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lblInstructions
            // 
            this.lblInstructions.AutoSize = true;
            this.lblInstructions.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstructions.Location = new System.Drawing.Point(136, 41);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(266, 13);
            this.lblInstructions.TabIndex = 0;
            this.lblInstructions.Text = "3.) Drag files into or out of the right pane to copy them. ";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(624, 536);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tvPaths);
            this.Controls.Add(this.tsMain);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.lvFiles);
            this.Controls.Add(this.lvRemoteSystemHeader);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Remote File System view and file copy utility";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tsMain.ResumeLayout(false);
            this.tsMain.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView tvPaths;
        private System.Windows.Forms.ListView lvFiles;
        private System.Windows.Forms.ImageList ilGlobal;
        private System.Windows.Forms.ColumnHeader chItemName;
        private System.Windows.Forms.ColumnHeader chLastModDate;
        private System.Windows.Forms.ColumnHeader chType;
        private System.Windows.Forms.ColumnHeader chFileSize;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbBack;
        private System.Windows.Forms.ToolStripTextBox currentPath;
        private System.Windows.Forms.ToolStrip tsMain;
        private System.Windows.Forms.ToolStripLabel lblStatus;
        private System.Windows.Forms.ListView lvRemoteSystemHeader;
        private System.Windows.Forms.ColumnHeader colRemoteSystem;
        private System.Windows.Forms.ToolStripButton btConnect;
        private System.Windows.Forms.ToolStripProgressBar pbFileTransfer;
        private System.Windows.Forms.ToolStripButton btTransferCancel;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

