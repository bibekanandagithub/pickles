﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tools;

namespace RemoteFileSystemServer
{
    public partial class frmMain : Form
    {
        private TcpComm.Server tcpServer;
        private TcpComm.Utilities.LargeArrayTransferHelper lat;
        private RemoteFileSystem.Server rfsServer;
        private Int32 currentSessionId = -1;
        private bool running = false;

        public frmMain()
        {
            InitializeComponent();
        }

        private void UI(Action code)
        {
            if (this.InvokeRequired) { this.Invoke((MethodInvoker)delegate() { UI(code); }); return; }
            code();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            String errMsg = "";
            tbIPAddress.Text = TcpComm.Server.GetLocalIpAddress().ToString();

            niSystrayIcon.Visible = true;
            
            // Initialize the TcpComm server here. Please see my atricle:
            // https://www.codeproject.com/articles/307315/reusable-multithreaded-tcp-client-and-server-class
            // for details on how to use it.
            tcpServer = new TcpComm.Server((Byte[] buffer, Int32 sessionId, Byte dataChannel) =>
            {
                if (dataChannel == 100)
                {
                    currentSessionId = sessionId;
                    String request = TcpComm.Utilities.BytesToString(buffer);
                    UI(() => LblStatus.Text = "Received data from client.");
                    rfsServer.RequestHandler(request);
                }
            }, 300000000);

            // We're going to be using LAT (Large Array Transfer Helper)
            lat = new TcpComm.Utilities.LargeArrayTransferHelper(ref tcpServer);
            
            // Initialize RemoteFileSystem here:
            rfsServer = new RemoteFileSystem.Server((String data) =>
            {

                // Send data to the client here:
                UI(() => LblStatus.Text = "Sending data to client.");
                lat.SendArray(TcpComm.Utilities.StrToByteArray(data), 100, currentSessionId, ref errMsg);
            }, (String newPath) =>
            {
                // Handle requests to update the TcpComm server's received files folder here:
                var session = tcpServer.GetSession(currentSessionId);
                if (session != null) { session.ReceivedFilesFolder = newPath; }
            });

            StartServer();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String errMsg = "";

            if(btStart.Text == "Start")
            {
                if (tcpServer.Start(int.Parse(tbPort.Text), ref errMsg))
                {
                    LblStatus.Text = "Server running.";
                    btStart.Text = "Stop";
                }
                else
                {
                    LblStatus.Text = "Couldn't start server: " + errMsg;
                }
            } else
            {
                try
                {
                    tcpServer.Close();
                } catch (Exception) { }

                btStart.Text = "Start";
                LblStatus.Text = "Server stopped.";
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                tcpServer.Close();
            } catch (Exception) { }

            niSystrayIcon.Visible = false;
        }

        private void frmMain_Shown(object sender, EventArgs e)
        {
            this.Visible = false;
        }

        private void startRFSServerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StartServer();
        }

        private void stopRFSServerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StopServer();
        }

        private void StartServer()
        {
            if (!running)
            {
                String errMsg = "";
                if (tcpServer.Start(int.Parse(tbPort.Text), ref errMsg))
                {
                    running = true;
                    niSystrayIcon.Text = "Running...";
                    niSystrayIcon.BalloonTipText = "Running...";
                    niSystrayIcon.ShowBalloonTip(5);
                }
            }
        }

        private void StopServer()
        {
            if (running)
            {
                try
                {
                    tcpServer.Close();
                }
                catch (Exception) { }

                running                         = false;
                niSystrayIcon.Text              = "Stopped.";
                niSystrayIcon.BalloonTipText    = "Stopped.";
                niSystrayIcon.ShowBalloonTip(5);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StopServer();
            this.Close();
        }
    }
}
